package com.example.demo.service;


import com.example.demo.dto.*;
import com.example.demo.entity.Item;
import com.example.demo.entity.OrderItem;
import com.example.demo.entity.Orders;
import com.example.demo.entity.UserEntity;
import com.example.demo.repository.ItemRepository;
import com.example.demo.repository.OrdersItemRepository;
import com.example.demo.repository.OrdersRepository;
import com.example.demo.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Log4j2
@Transactional
public class OrdersService {

    private final OrdersRepository ordersRepository;
    private final OrdersItemRepository ordersItemRepository;
    private final UserRepository userRepository;
    private final ItemRepository itemRepository;


    //상품 주문
    public String register(OrderItemDTO orderItemDTO , String email){

        log.info("데이터 :  " + orderItemDTO);

        //email를 이용해서 주문을 만들어서 주문안에 주문아이템을 넣는다.
        UserEntity userEntity = userRepository.findByEmail(email);

        Orders orders = Orders.builder()
                .userEntity(userEntity)
                .build();
        //저장하고 엔티티를 반환한다.
        orders = ordersRepository.save(orders);

        //사는 아이템
        Item item = itemRepository.findById(orderItemDTO.getOino())
                .orElseThrow(EntityNotFoundException::new);

        //주문 아이템
        OrderItem orderItem = OrderItem.builder()
                .item(item)     //사는 아이템
                .orders(orders)       // 사는 주문
                .oiCount(orderItemDTO.getOiCount())      // 수량
                .build();

        orderItem = ordersItemRepository.save(orderItem);

        return orderItem.getItem().getIName();//주문한 상품명
    }


    //주문 리스트
    public ResponsePageDTO list(RequestPageDTO requestPageDTO , String  email) {

        Pageable pageable = PageRequest.of(requestPageDTO.getPage(),10, Sort.by("oino"));

        Page<OrderItem> orderItemPage =
        ordersItemRepository.selectOrdersEmail(email ,pageable);

        List<OrderItem>  itemList = orderItemPage.getContent();

        List<OrderItemDTO> c = new ArrayList<>();

        ModelMapper modelMapper = new ModelMapper();
        for (OrderItem orderItem : itemList) {

            OrderItemDTO orderItemDTO = modelMapper.map(orderItem, OrderItemDTO.class);

            orderItemDTO.setOrdersDTO(  modelMapper.map( orderItem.getOrders() , OrdersDTO.class)   );

            orderItemDTO.setItemDTO(    modelMapper.map( orderItem.getItem() , ItemDTO.class)   );

            c.add(orderItemDTO);
        }

        ResponsePageDTO<OrderItemDTO> a
                = new ResponsePageDTO<>(c , requestPageDTO.getPage() , (int) orderItemPage.getTotalElements());

        return a;

    }









}

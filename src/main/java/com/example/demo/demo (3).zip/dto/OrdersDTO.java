package com.example.demo.dto;

import com.example.demo.entity.UserEntity;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrdersDTO {

    private Long ono;

    private UserDTO userDTO;
}

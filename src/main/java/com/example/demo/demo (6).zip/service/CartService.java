package com.example.demo.service;

import com.example.demo.dto.CartItemDTO;
import com.example.demo.entity.Cart;
import com.example.demo.entity.CartItem;
import com.example.demo.entity.Item;
import com.example.demo.entity.UserEntity;
import com.example.demo.repository.CartItemRepository;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.ItemRepository;
import com.example.demo.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
@Log4j2
public class CartService {
    private final UserRepository userRepository;
    private final ItemRepository itemRepository;
    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;


    //사용자가 로그인(컨트롤러)후
    //이메일을 이용해서 장바구니를 만든다.
    //아이템을 참조한 카트아이템들을 장바구니에 담는다.
    public void register(String email, List<CartItemDTO> cartItemDTOList ){


        //사용자 이메일로 검색 없으면 예외처리
        UserEntity userEntity = userRepository.findByEmail(email);

        if(userEntity == null) {
            throw new IllegalArgumentException("잘못된 접근입니다.");//이메일 사용자를 못찾음
        }

        //장바구니
        Cart cart = cartRepository.findByUserEntityEmail(email);    //로그인사용자의 이메일로 장바구니 불러오기

        //장바구니가 없다면
        if(cart == null) {
            cart = new Cart();
            cart.setUserEntity(userEntity);     //로그인한 사용자 참조
        }
        //장바구니에 아이템들을 담을 목록들

        //장바구니 아이템들 찾아오기
        for(CartItemDTO cartItemDTO : cartItemDTOList){
            //참조 대상인 아이템들 가져오기 : 없다면 예외처리
            Item item = itemRepository.findById(cartItemDTO.getItemid()).orElseThrow(EntityNotFoundException::new);
            //장바구니 아이템
            CartItem cartItem = new CartItem();
            cartItem.setItem(item);
            cartItem.setCart(cart);
            cartItem.setCount(cartItemDTO.getCount());        //수량

            cart.addCartItemList(cartItem);

        }

        cartRepository.save(cart);




    }



}

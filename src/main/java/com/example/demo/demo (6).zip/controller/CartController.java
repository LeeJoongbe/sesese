package com.example.demo.controller;

import com.example.demo.dto.CartItemDTO;
import com.example.demo.dto.CartItemDTOS;
import com.example.demo.service.CartService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.List;

@Controller
@RequiredArgsConstructor
@Log4j2
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;


    @PostMapping("/register")
    public String register(
            @Valid  CartItemDTOS cartItemDTOS, BindingResult bindingResult ,
            Principal principal, RedirectAttributes redirectAttributes){

        log.info("들어온값 : " + cartItemDTOS);

        if(bindingResult.hasErrors()) {

//            bindingResult.getAllErrors(); 리다일렉트로 넘기기

            redirectAttributes.addFlashAttribute("msg" , "수량 등 입력값이 올바르지 않습니다.");

            return "redirect:/item/list";   //기존 아이템list는 url item/list -> admin/item/list
        }

        try {
            cartService.register(principal.getName() , cartItemDTOS.getCartItemDTOList());
        }catch (EntityNotFoundException e){
            redirectAttributes.addFlashAttribute("msg" , "수량 등 입력값이 올바르지 않습니다.");
            return "redirect:/item/list";   //기존 아이템list는 url item/list -> admin/item/list

        }catch (IllegalArgumentException e){
            redirectAttributes.addFlashAttribute("msg" , e.getMessage());
            return "redirect:/item/list";   //기존 아이템list는 url item/list -> admin/item/list
        }

        return "redirect:/cart/list";   //성공시 장바구니 목록

    }

}

package com.example.demo.constant;

public enum ItemStatus {

    SELL , SOLDOUT
}

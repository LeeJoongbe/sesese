package com.example.demo.entity;

public class Aaaa {

    String title;
    String content;
    String writer;

    public String getTitle() {
        return title;
    }

    public Aaaa setTitle(String title) {
        this.title = title;
        return this;
    }
    public Aaaa setContent(String content) {
        this.content = content;
        return this;
    }
    public Aaaa setWriter(String writer) {
        this.writer = writer;
        return this;
    }

    public String getContent() {
        return content;
    }


    public String getWriter() {
        return writer;
    }


}

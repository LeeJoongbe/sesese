package com.example.demo.dto;

import com.example.demo.entity.UserEntity;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemDTO {
    private Long ino;

    private String iName;
    private String iDetail;
    private Integer iCount;
    private Integer iPrice;

    private UserDTO userDTO;



}

package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ino;

    private String iName;
    private String iDetail;
    private Integer iCount;
    private Integer iPrice;

    @ManyToOne
    @JoinColumn(name = "uno")
    private UserEntity userEntity;



}

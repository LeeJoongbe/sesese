package com.example.demo.util;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.UUID;

public class FileUpload {



    public void save (MultipartFile multipartFile) {

        if(!multipartFile.isEmpty()) {

            //파일명을 가져와서 파일명을 가지고 uuid변환
            String  originalFilename = multipartFile.getOriginalFilename();

            String newFileName = UUID.randomUUID().toString() + "_" + originalFilename; //폴도저장용/디비저장용
            // 경로 + 파일명

//
//            File file = new File();
//            multipartFile.t



        }


    }
}

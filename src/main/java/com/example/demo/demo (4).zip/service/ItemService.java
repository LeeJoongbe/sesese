package com.example.demo.service;


import com.example.demo.constant.ItemStatus;
import com.example.demo.dto.ItemDTO;
import com.example.demo.entity.Item;
import com.example.demo.entity.UserEntity;
import com.example.demo.repository.ItemRepository;
import com.example.demo.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Log4j2
@Transactional
public class ItemService {


    private final ItemRepository itemRepository;
    private final UserRepository userRepository;

    private ModelMapper modelMapper = new ModelMapper();


    //등록

    public Long register(ItemDTO itemDTO , String email){

        //판매상태는 무조건 처음은 품절상태 시작
        itemDTO.setItemStatus(ItemStatus.SOLDOUT);

        //상품을 저장하기위해서 누가 판매하고 있는가? 유저정보를 가져와야한다.
        //email
        //부모값
        UserEntity userEntity =
        userRepository.findByEmail(email);

        //ItemDTO를 엔티티로 변형
        Item item = modelMapper.map(itemDTO , Item.class);

        //부모값 세팅
        item.setUserEntity( userEntity );

        item = itemRepository.save(item);

        return item.getIno();

    }

    //pk번호를 받아서 ItemDTO객체로 반환하는 기능을 가진 메서드
    public ItemDTO read(Long ino , String email){
        Item item =
        itemRepository.findById(ino)
                .orElseThrow(EntityNotFoundException::new);
        //dto변환
//        ItemDTO itemDTO  = modelMapper.map(item, ItemDTO.class);
//        return itemDTO;

        if(!item.getUserEntity().getEmail().equals(email)) {
            //상품의 등록자와 현재 로그인한 대상 다르다면
            throw new IllegalArgumentException("잘못된 접근입니다.");
        }


        return modelMapper.map(item, ItemDTO.class);

    }

    //상품의 pk번호를 받아서 , 데이터를 찾아와서
    // dto에 변경할 내용들을 적용해서 수정한다.
    // 단!! 아이템의 등록자와 현재 로그인한 사람이 같다면
    public Long update(ItemDTO itemDTO , String email) {


        Item item =
        itemRepository.findById(itemDTO.getIno())
                .orElseThrow(EntityNotFoundException::new);

        if(!item.getUserEntity().getEmail().equals(email)) {
            //상품의 등록자와 현재 로그인한 대상 다르다면
            throw new IllegalArgumentException("잘못된 접근입니다.");
        }

        //수정작업
        item.setICount(itemDTO.getICount());
        item.setIPrice(itemDTO.getIPrice());
        item.setIName(itemDTO.getIName());
        item.setIDetail(itemDTO.getIDetail());

        return item.getIno();
    }


    public void del (ItemDTO itemDTO , String email){
        Item item =
                itemRepository.findById(itemDTO.getIno())
                        .orElseThrow(EntityNotFoundException::new);

        if(!item.getUserEntity().getEmail().equals(email)) {
            //상품의 등록자와 현재 로그인한 대상 다르다면
            throw new IllegalArgumentException("잘못된 접근입니다.");
        }

        itemRepository.delete(item);
    }

}
